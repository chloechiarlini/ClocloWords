import {defineConfig} from "vite";import react from "@vitejs/plugin-react";import tailwind from "@tailwindcss/vite";import {viteSingleFile} from "vite-plugin-singlefile";
export default defineConfig({base:"./",plugins:[react(),tailwind(),viteSingleFile()]});
